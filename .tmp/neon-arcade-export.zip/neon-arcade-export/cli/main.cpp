#include <iostream>
#include <string>

int main() {
  std::cout << "Codegen Studio CLI" << std::endl;
  std::cout << "Project: neon-arcade-export" << std::endl;
  std::cout << "Runtime: desktop" << std::endl;
  std::cout << "Package: arcade_lobby" << std::endl;
  std::cout << "Tone: neon" << std::endl;
  std::cout << "Brief: Validates the Codegen Studio bundle outputs." << std::endl;
  std::cout << "Zip contains sample Next.js + CLI scaffolding." << std::endl;
  return 0;
}
