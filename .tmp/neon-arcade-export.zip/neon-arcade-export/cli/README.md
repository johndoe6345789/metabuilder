# CLI companion

This CLI mirrors the Codegen Studio configuration for neon-arcade-export.
Use it to inspect queue metadata before exporting.