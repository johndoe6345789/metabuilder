export default function Page() {
  return (
    <main style={{ minHeight: '100vh', padding: '3rem', fontFamily: 'system-ui, sans-serif' }}>
      <h1>neon-arcade-export</h1>
      <p>Validates the Codegen Studio bundle outputs.</p>
      <p>Runtime focus: Desktop shell</p>
      <p>Tone: neon</p>
    </main>
  )
}
